using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("CustomizationTool")]
[assembly: AssemblyDescription("A tool to customize AMLogic and Rockchip firmware")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("RD-Soft")]
[assembly: AssemblyProduct("CustomizationTool")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("72e5aec1-1124-4ebe-b071-44d50b1607f5")]
[assembly: AssemblyFileVersion("0.10.1.0")]
[assembly: AssemblyVersion("0.10.1.0")]
[module: ConfusedBy("Confuser.Core 1.6.0+447341964f")]
